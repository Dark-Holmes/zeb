/**
 * ZEB Platform — main.js
 * JavaScript principal (Vanilla JS, aucune dépendance)
 * Modules : navbar, dropdown, toast, tabs, modals, forms, chat
 */

/* ══ 1. NAVBAR ══════════════════════════════════════════ */
const navbar = document.getElementById('navbar');
if (navbar) {
    // Ombre au scroll
    window.addEventListener('scroll', () => {
        navbar.classList.toggle('scrolled', window.scrollY > 8);
    }, { passive: true });
}

// Menu burger mobile
const navToggle = document.getElementById('navToggle');
const navLinks  = document.getElementById('navLinks');
if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => {
        navLinks.classList.toggle('open');
        const spans = navToggle.querySelectorAll('span');
        const open  = navLinks.classList.contains('open');
        spans[0].style.transform = open ? 'rotate(45deg) translate(5px,5px)'  : '';
        spans[1].style.opacity   = open ? '0' : '';
        spans[2].style.transform = open ? 'rotate(-45deg) translate(5px,-5px)': '';
    });
    navLinks.querySelectorAll('a').forEach(a => {
        a.addEventListener('click', () => navLinks.classList.remove('open'));
    });
}

// Dropdown utilisateur
const userBtn  = document.getElementById('userBtn');
const userDrop = document.getElementById('userDrop');
if (userBtn && userDrop) {
    userBtn.addEventListener('click', e => {
        e.stopPropagation();
        userDrop.classList.toggle('open');
    });
    document.addEventListener('click', () => userDrop.classList.remove('open'));
}

// Lien actif selon l'URL
document.querySelectorAll('.nav-link').forEach(link => {
    const href = link.getAttribute('href');
    if (href && href !== '#' && window.location.pathname.includes(href.replace('.html',''))) {
        link.classList.add('active');
    }
});

/* ══ 2. TOASTS / FLASH MESSAGES ════════════════════════ */
/**
 * Affiche un toast de notification.
 * @param {string} msg     - Message à afficher
 * @param {string} type    - 'success' | 'error' | 'info' | 'warning'
 * @param {number} duration - Durée en ms (défaut 4000)
 */
function showToast(msg, type = 'success', duration = 4000) {
    let container = document.querySelector('.toast-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'toast-container';
        document.body.appendChild(container);
    }
    const icons = { success:'fa-circle-check', error:'fa-circle-xmark', info:'fa-circle-info', warning:'fa-triangle-exclamation' };
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `<i class="fas ${icons[type]}"></i><span>${msg}</span><button class="toast-close" onclick="this.parentElement.remove()">×</button>`;
    container.appendChild(toast);
    setTimeout(() => {
        toast.style.opacity = '0'; toast.style.transform = 'translateX(20px)'; toast.style.transition = '.4s';
        setTimeout(() => toast.remove(), 400);
    }, duration);
}

// Auto-fermeture des toasts existants dans le HTML
document.querySelectorAll('.toast').forEach(t => {
    setTimeout(() => { t.style.opacity='0'; t.style.transform='translateX(20px)'; t.style.transition='.4s'; setTimeout(()=>t.remove(),400); }, 4000);
});

/* ══ 3. MODALS ══════════════════════════════════════════ */
/**
 * Ouvre un modal.
 * @param {string} id - ID du .modal-overlay
 */
function openModal(id) {
    const el = document.getElementById(id);
    if (el) { el.classList.add('open'); document.body.style.overflow = 'hidden'; }
}
function closeModal(id) {
    const el = document.getElementById(id);
    if (el) { el.classList.remove('open'); document.body.style.overflow = ''; }
}

// Fermer au clic sur l'overlay
document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', e => {
        if (e.target === overlay) closeModal(overlay.id);
    });
});
// Boutons [data-modal-open] et [data-modal-close]
document.querySelectorAll('[data-modal-open]').forEach(btn => {
    btn.addEventListener('click', () => openModal(btn.dataset.modalOpen));
});
document.querySelectorAll('[data-modal-close]').forEach(btn => {
    btn.addEventListener('click', () => closeModal(btn.dataset.modalClose));
});
// Fermer avec Echap
document.addEventListener('keydown', e => {
    if (e.key === 'Escape') document.querySelectorAll('.modal-overlay.open').forEach(m => m.classList.remove('open'));
});

/* ══ 4. TABS ════════════════════════════════════════════ */
/**
 * Gestion des onglets génériques.
 * Structure : .tabs-nav > .tab-btn[data-tab="id"] et .tab-panel#id
 */
document.querySelectorAll('.tabs-nav').forEach(nav => {
    nav.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const target = btn.dataset.tab;
            const wrap   = btn.closest('.tabs-wrap') || document;
            wrap.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            wrap.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
            btn.classList.add('active');
            document.getElementById(target)?.classList.add('active');
        });
    });
});

/* ══ 5. FORCE MOT DE PASSE ══════════════════════════════ */
/**
 * Évalue la force d'un mot de passe et met à jour
 * la barre visuelle + le label textuel.
 */
document.querySelectorAll('input[type=password][data-strength]').forEach(input => {
    const barId   = input.dataset.strength;
    const labelId = input.dataset.label;
    input.addEventListener('input', function() {
        const v = this.value;
        let score = 0;
        if (v.length >= 8)             score++;
        if (/[A-Z]/.test(v))           score++;
        if (/[0-9]/.test(v))           score++;
        if (/[^A-Za-z0-9]/.test(v))   score++;
        const levels = [
            { pct:'20%', color:'#D32F2F', label:'Trop court' },
            { pct:'40%', color:var_orange, label:'Faible' },
            { pct:'60%', color:'#FDD835', label:'Moyen' },
            { pct:'80%', color:'#8BC34A', label:'Fort' },
            { pct:'100%',color:'#4CAF50', label:'Excellent' },
        ];
        const lv = levels[score];
        const bar = document.getElementById(barId);
        if (bar) { bar.style.width = v.length ? lv.pct : '0'; bar.style.background = lv.color; }
        const lbl = document.getElementById(labelId);
        if (lbl) { lbl.textContent = v.length ? lv.label : ''; lbl.style.color = lv.color; }
    });
});
const var_orange = '#F47B20'; // fallback pour le niveau 1

/* ══ 6. TOGGLE MOT DE PASSE ════════════════════════════ */
document.querySelectorAll('.eye-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        const input = this.closest('.input-eye').querySelector('input');
        const icon  = this.querySelector('i');
        input.type = input.type === 'password' ? 'text' : 'password';
        icon.className = input.type === 'password' ? 'fas fa-eye' : 'fas fa-eye-slash';
    });
});

/* ══ 7. SÉLECTEUR DE RÔLE (inscription) ════════════════ */
document.querySelectorAll('.role-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        this.closest('.role-selector').querySelectorAll('.role-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        const roleInput = document.getElementById('roleInput');
        if (roleInput) roleInput.value = this.dataset.role;
        updateAuthPanel(this.dataset.role);
        const companyRow = document.getElementById('companyRow');
        if (companyRow) companyRow.style.display = ['client','transporteur'].includes(this.dataset.role) ? '' : 'none';
        const loaderRow = document.getElementById('loaderRow');
        if (loaderRow) loaderRow.style.display = this.dataset.role === 'chargeur' ? '' : 'none';
    });
});

function updateAuthPanel(role) {
    const panel = document.getElementById('authPanelContent');
    if (!panel) return;
    const data = {
        client:       { icon:'fa-building',    title:'Espace Client',       desc:'Publiez vos besoins, recevez des offres et suivez vos livraisons en temps réel.', feats:['Demandes illimitées','Suivi GPS temps réel','Messagerie intégrée','Notation des prestataires'] },
        transporteur: { icon:'fa-truck-fast',   title:'Espace Transporteur', desc:'Trouvez des missions et développez votre clientèle sur toute la plateforme.',     feats:['Accès à toutes les demandes','Soumission d\'offres','Gestion de flotte','Profil vérifiable'] },
        chargeur:     { icon:'fa-hard-hat',     title:'Espace Chargeur',     desc:'Proposez vos services de manutention sur les missions disponibles.',               feats:['Missions chargement/déchargement','Affectation directe','Signalement fin mission','Évaluations'] },
    };
    const d = data[role];
    if (!d) return;
    panel.innerHTML = `
        <span class="auth-panel-icon"><i class="fas ${d.icon}"></i></span>
        <h3>${d.title}</h3><p>${d.desc}</p>
        <div class="auth-features">${d.feats.map(f=>`<div class="auth-feature"><i class="fas fa-check"></i> ${f}</div>`).join('')}</div>`;
}

/* ══ 8. COMPTES DÉMO (login) ════════════════════════════ */
function fillDemo(email) {
    const emailInput = document.getElementById('emailInput');
    const passInput  = document.getElementById('passInput');
    if (emailInput) emailInput.value = email;
    if (passInput)  passInput.value  = 'Demo@1234';
    showToast('Identifiants pré-remplis — cliquez sur Se connecter', 'info');
}

/* ══ 9. UPLOAD PHOTO ════════════════════════════════════ */
document.querySelectorAll('.upload-zone').forEach(zone => {
    const input   = zone.querySelector('input[type=file]');
    const preview = zone.querySelector('.file-preview');
    const ui      = zone.querySelector('.upload-ui');
    if (!input) return;
    input.addEventListener('change', function() {
        if (!this.files[0]) return;
        const reader = new FileReader();
        reader.onload = e => {
            if (preview) { preview.src = e.target.result; preview.style.display = 'block'; }
            if (ui) ui.style.display = 'none';
        };
        reader.readAsDataURL(this.files[0]);
    });
    ['dragenter','dragover'].forEach(ev => zone.addEventListener(ev, e => { e.preventDefault(); zone.classList.add('drag'); }));
    ['dragleave','drop'].forEach(ev => zone.addEventListener(ev, e => { e.preventDefault(); zone.classList.remove('drag'); if (ev === 'drop') { input.files = e.dataTransfer.files; input.dispatchEvent(new Event('change')); } }));
});

/* ══ 10. TOGGLE SECTION LOADER ══════════════════════════ */
function toggleLoader(cb) {
    const sec = document.getElementById('loaderSection');
    if (sec) sec.style.display = cb.checked ? 'block' : 'none';
}

/* ══ 11. CHAT — textarea auto-hauteur ══════════════════ */
document.querySelectorAll('.chat-input').forEach(input => {
    input.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 120) + 'px';
    });
    // Envoi avec Entrée (pas Shift+Entrée)
    input.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            const msg = this.value.trim();
            if (msg) { sendMessage(msg); this.value = ''; this.style.height = 'auto'; }
        }
    });
});

/* Simulation d'envoi d'un message dans la démo */
function sendMessage(text) {
    const chatMessages = document.getElementById('chatMessages');
    if (!chatMessages) return;
    const now   = new Date();
    const time  = now.getHours().toString().padStart(2,'0') + ':' + now.getMinutes().toString().padStart(2,'0');
    const wrap  = document.createElement('div');
    wrap.className = 'bubble-wrap me fade-up';
    wrap.innerHTML = `<div class="bubble"><div class="bubble-text">${text.replace(/</g,'&lt;')}</div><div class="bubble-time">${time} <i class="fas fa-check-double" style="color:rgba(255,255,255,.6)"></i></div></div>`;
    chatMessages.appendChild(wrap);
    chatMessages.scrollTop = chatMessages.scrollHeight;

    // Réponse automatique simulée après 1.2s
    setTimeout(() => {
        const autoReply = document.createElement('div');
        autoReply.className = 'bubble-wrap them fade-up';
        const replies = ['Bien reçu, merci !', 'Je confirme pour demain matin.', 'Parfait, à demain.', 'D\'accord, je serai là.'];
        const reply   = replies[Math.floor(Math.random() * replies.length)];
        const t2 = new Date();
        const t2s = t2.getHours().toString().padStart(2,'0') + ':' + t2.getMinutes().toString().padStart(2,'0');
        autoReply.innerHTML = `<div class="avatar avatar-sm" style="background:var(--orange)">P</div><div class="bubble"><div class="bubble-text">${reply}</div><div class="bubble-time">${t2s}</div></div>`;
        chatMessages.appendChild(autoReply);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }, 1200);
}

/* ══ 12. BOUTONS D'ENVOI CHAT ═══════════════════════════ */
document.querySelectorAll('.chat-send').forEach(btn => {
    btn.addEventListener('click', () => {
        const input = btn.closest('.chat-input-row')?.querySelector('.chat-input');
        if (input) { const msg = input.value.trim(); if (msg) { sendMessage(msg); input.value = ''; input.style.height='auto'; } }
    });
});

/* ══ 13. AUTO-SCROLL CHAT ═══════════════════════════════ */
const chatMessages = document.getElementById('chatMessages');
if (chatMessages) chatMessages.scrollTop = chatMessages.scrollHeight;

/* ══ 14. SIMULATION GPS (page tracking) ════════════════ */
function initDemo() {
    // Les demandes flottantes du hero ont un délai pour animer
    document.querySelectorAll('.float-card').forEach((c, i) => {
        c.style.animationDelay = (i * 0.4) + 's';
    });
}

/* ══ 15. SMOOTH SCROLL ══════════════════════════════════ */
document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', function(e) {
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            e.preventDefault();
            window.scrollTo({ top: target.getBoundingClientRect().top + window.scrollY - 80, behavior: 'smooth' });
        }
    });
});

/* ══ 16. FILTRES (page browse) ══════════════════════════ */
function applyFilters() {
    const origin  = document.getElementById('filterOrigin')?.value.toLowerCase() || '';
    const dest    = document.getElementById('filterDest')?.value.toLowerCase()   || '';
    const goods   = document.getElementById('filterGoods')?.value.toLowerCase()  || '';
    document.querySelectorAll('.load-card[data-origin]').forEach(card => {
        const cardOrigin = card.dataset.origin?.toLowerCase() || '';
        const cardDest   = card.dataset.dest?.toLowerCase()   || '';
        const cardGoods  = card.dataset.goods?.toLowerCase()  || '';
        const visible = (!origin || cardOrigin.includes(origin))
                     && (!dest   || cardDest.includes(dest))
                     && (!goods  || cardGoods.includes(goods));
        card.style.display = visible ? '' : 'none';
    });
}
document.querySelectorAll('#filterOrigin,#filterDest,#filterGoods').forEach(input => {
    if (input) input.addEventListener('input', applyFilters);
});

/* ══ 17. CONFIRMATION ACTIONS CRITIQUES ═════════════════ */
document.querySelectorAll('[data-confirm]').forEach(el => {
    el.addEventListener('click', function(e) {
        if (!confirm(this.dataset.confirm)) e.preventDefault();
    });
});

/* ══ INIT ═══════════════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', () => {
    initDemo();
    console.log('%c🚚 ZEB Platform %cFrontend v1.0', 'background:#0056A6;color:#fff;padding:3px 8px;border-radius:4px;font-weight:bold','color:#6B7280');
});
